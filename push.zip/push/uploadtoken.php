<?php
	$deviceToken = $_REQUEST['token'];
	echo $deviceToken;
	$myFile = "token.txt";
	
	$fh = fopen($myFile, 'r') or die("can't open file");
	$data = fread($fh, 4096);
	fclose($fh);
	
	$fh = fopen($myFile, 'w') or die("can't open file");
	fwrite($fh, $data);
	fwrite($fh, $deviceToken."\t\t".date("Y-m-d H:i:s")."\n");
	fclose($fh);
	
?>
